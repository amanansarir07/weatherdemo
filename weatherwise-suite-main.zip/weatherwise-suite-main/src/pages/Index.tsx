import { WeatherCard } from "@/components/WeatherCard";
import { ForecastCard } from "@/components/ForecastCard";
import { WeatherDetails } from "@/components/WeatherDetails";
import { SearchBar } from "@/components/SearchBar";
import { useWeather } from "@/hooks/useWeather";
import { Cloud } from "lucide-react";

const Index = () => {
  const { weatherData, isLoading, fetchWeather } = useWeather();

  return (
    <div className="min-h-screen bg-sky-gradient">
      <div className="container max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Cloud className="h-10 w-10 text-primary" />
            <h1 className="text-4xl font-bold text-white drop-shadow-lg">
              Weather Pro
            </h1>
          </div>
          <p className="text-white/80 text-lg drop-shadow">
            Professional weather forecasting at your fingertips
          </p>
        </div>

        {/* Search Bar */}
        <SearchBar onSearch={fetchWeather} isLoading={isLoading} />

        {/* Loading State */}
        {isLoading && (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
            <p className="text-white/80">Loading weather data...</p>
          </div>
        )}

        {/* Weather Content */}
        {!isLoading && weatherData.current && (
          <div className="space-y-6">
            {/* Current Weather */}
            <WeatherCard
              location={weatherData.current.location}
              temperature={weatherData.current.temperature}
              condition={weatherData.current.condition}
              description={weatherData.current.description}
              feelsLike={weatherData.current.feelsLike}
              icon={weatherData.current.icon}
            />

            {/* Forecast and Details Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ForecastCard forecast={weatherData.forecast} />
              
              <WeatherDetails
                humidity={weatherData.current.humidity}
                windSpeed={weatherData.current.windSpeed}
                visibility={weatherData.current.visibility}
                pressure={weatherData.current.pressure}
                sunrise={weatherData.current.sunrise}
                sunset={weatherData.current.sunset}
              />
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="text-center mt-12 pt-8 border-t border-white/20">
          <p className="text-white/60 text-sm">
            Weather data provided by professional meteorological services
          </p>
        </div>
      </div>
    </div>
  );
};

export default Index;
