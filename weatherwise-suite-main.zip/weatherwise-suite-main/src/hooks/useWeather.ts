import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

// Using OpenWeatherMap API (free tier)
const API_KEY = "demo_key"; // In a real app, this would be from environment variables
const BASE_URL = "https://api.openweathermap.org/data/2.5";

interface CurrentWeather {
  location: string;
  temperature: number;
  condition: string;
  description: string;
  feelsLike: number;
  humidity: number;
  windSpeed: number;
  visibility: number;
  pressure: number;
  icon: string;
  sunrise?: string;
  sunset?: string;
}

interface ForecastItem {
  date: string;
  day: string;
  icon: string;
  high: number;
  low: number;
  description: string;
}

interface WeatherData {
  current: CurrentWeather | null;
  forecast: ForecastItem[];
}

export function useWeather() {
  const [weatherData, setWeatherData] = useState<WeatherData>({
    current: null,
    forecast: []
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  // Mock data for demo purposes (since we don't have a real API key)
  const getMockWeatherData = (city: string): WeatherData => {
    const cities = ['New York', 'London', 'Tokyo', 'Paris', 'Sydney'];
    const randomCity = cities[Math.floor(Math.random() * cities.length)];
    
    return {
      current: {
        location: city.includes(',') ? 'Current Location' : city || randomCity,
        temperature: Math.round(Math.random() * 30 + 5),
        condition: 'Partly Cloudy',
        description: 'scattered clouds',
        feelsLike: Math.round(Math.random() * 30 + 5),
        humidity: Math.round(Math.random() * 40 + 30),
        windSpeed: Math.round(Math.random() * 10 + 2),
        visibility: Math.round(Math.random() * 5000 + 5000),
        pressure: Math.round(Math.random() * 50 + 1000),
        icon: '02d',
        sunrise: '06:30',
        sunset: '19:45'
      },
      forecast: Array.from({ length: 5 }, (_, i) => ({
        date: new Date(Date.now() + i * 24 * 60 * 60 * 1000).toISOString(),
        day: new Date(Date.now() + i * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { weekday: 'short' }),
        icon: ['01d', '02d', '03d', '10d', '11d'][i],
        high: Math.round(Math.random() * 25 + 15),
        low: Math.round(Math.random() * 15 + 5),
        description: ['clear sky', 'few clouds', 'scattered clouds', 'light rain', 'thunderstorm'][i]
      }))
    };
  };

  const fetchWeather = async (cityOrCoords: string) => {
    setIsLoading(true);
    setError(null);

    try {
      // Since we don't have a real API key, we'll use mock data
      // In a real implementation, you would:
      // 1. Add the API key as a secret using the Lovable secrets system
      // 2. Make actual API calls to OpenWeatherMap
      
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay
      
      const mockData = getMockWeatherData(cityOrCoords);
      setWeatherData(mockData);
      
      toast({
        title: "Weather Updated",
        description: `Showing weather for ${mockData.current?.location}`,
      });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Failed to fetch weather data";
      setError(errorMessage);
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Load initial weather data for a default city
  useEffect(() => {
    fetchWeather("New York");
  }, []);

  return {
    weatherData,
    isLoading,
    error,
    fetchWeather
  };
}