import { Card } from "@/components/ui/card";
import { Droplets, Wind, Eye, Gauge } from "lucide-react";

interface WeatherDetailsProps {
  humidity: number;
  windSpeed: number;
  visibility: number;
  pressure: number;
  uvIndex?: number;
  sunrise?: string;
  sunset?: string;
}

export function WeatherDetails({ 
  humidity, 
  windSpeed, 
  visibility, 
  pressure,
  uvIndex,
  sunrise,
  sunset
}: WeatherDetailsProps) {
  const details = [
    {
      icon: Droplets,
      label: "Humidity",
      value: `${humidity}%`,
      color: "text-blue-500"
    },
    {
      icon: Wind,
      label: "Wind Speed",
      value: `${Math.round(windSpeed)} m/s`,
      color: "text-cyan-500"
    },
    {
      icon: Eye,
      label: "Visibility",
      value: `${Math.round(visibility / 1000)} km`,
      color: "text-indigo-500"
    },
    {
      icon: Gauge,
      label: "Pressure",
      value: `${pressure} hPa`,
      color: "text-purple-500"
    }
  ];

  return (
    <Card className="p-6 bg-weather-card shadow-card border-0">
      <h3 className="text-lg font-semibold text-foreground mb-4">Weather Details</h3>
      
      <div className="grid grid-cols-2 gap-4">
        {details.map((detail, index) => (
          <div 
            key={detail.label}
            className="flex items-center gap-3 p-3 rounded-lg bg-detail-accent/20 hover:bg-detail-accent/30 transition-colors"
          >
            <div className={`p-2 rounded-full bg-white/80 ${detail.color}`}>
              <detail.icon className="h-4 w-4" />
            </div>
            <div>
              <div className="text-sm text-muted-foreground">{detail.label}</div>
              <div className="font-semibold text-foreground">{detail.value}</div>
            </div>
          </div>
        ))}
      </div>

      {(sunrise || sunset || uvIndex) && (
        <div className="mt-4 pt-4 border-t border-border">
          <div className="grid grid-cols-1 gap-2 text-sm">
            {sunrise && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Sunrise</span>
                <span className="font-medium text-foreground">{sunrise}</span>
              </div>
            )}
            {sunset && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Sunset</span>
                <span className="font-medium text-foreground">{sunset}</span>
              </div>
            )}
            {uvIndex && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">UV Index</span>
                <span className="font-medium text-foreground">{uvIndex}</span>
              </div>
            )}
          </div>
        </div>
      )}
    </Card>
  );
}