import { Card } from "@/components/ui/card";

interface ForecastItem {
  date: string;
  day: string;
  icon: string;
  high: number;
  low: number;
  description: string;
}

interface ForecastCardProps {
  forecast: ForecastItem[];
}

export function ForecastCard({ forecast }: ForecastCardProps) {
  return (
    <Card className="p-6 bg-forecast-bg shadow-card border-0">
      <h3 className="text-lg font-semibold text-foreground mb-4">5-Day Forecast</h3>
      
      <div className="space-y-4">
        {forecast.map((item, index) => (
          <div 
            key={item.date}
            className="flex items-center justify-between py-3 border-b border-border last:border-b-0 transition-colors hover:bg-muted/30 rounded-md px-2 -mx-2"
          >
            <div className="flex items-center gap-4 flex-1">
              <div className="w-16 text-left">
                <div className="font-medium text-foreground">
                  {index === 0 ? 'Today' : item.day}
                </div>
                <div className="text-sm text-muted-foreground capitalize">
                  {item.description}
                </div>
              </div>
              
              <div className="text-3xl">
                {getWeatherEmoji(item.icon)}
              </div>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-lg font-semibold text-temperature-primary">
                {Math.round(item.high)}°
              </span>
              <span className="text-muted-foreground">
                {Math.round(item.low)}°
              </span>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

function getWeatherEmoji(icon: string): string {
  const iconMap: { [key: string]: string } = {
    '01d': '☀️', '01n': '🌙',
    '02d': '⛅', '02n': '☁️',
    '03d': '☁️', '03n': '☁️',
    '04d': '☁️', '04n': '☁️',
    '09d': '🌧️', '09n': '🌧️',
    '10d': '🌦️', '10n': '🌧️',
    '11d': '⛈️', '11n': '⛈️',
    '13d': '🌨️', '13n': '🌨️',
    '50d': '🌫️', '50n': '🌫️',
  };
  return iconMap[icon] || '☀️';
}