import { Card } from "@/components/ui/card";
import { MapPin, Thermometer } from "lucide-react";

interface WeatherCardProps {
  location: string;
  temperature: number;
  condition: string;
  description: string;
  feelsLike: number;
  icon: string;
}

export function WeatherCard({ 
  location, 
  temperature, 
  condition, 
  description, 
  feelsLike,
  icon 
}: WeatherCardProps) {
  return (
    <Card className="p-8 bg-weather-card shadow-weather border-0 overflow-hidden relative">
      <div className="absolute inset-0 bg-sky-gradient opacity-5" />
      
      <div className="relative z-10">
        <div className="flex items-center gap-2 mb-6">
          <MapPin className="h-5 w-5 text-muted-foreground" />
          <span className="text-lg font-medium text-foreground">{location}</span>
        </div>

        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="text-6xl font-bold text-temperature-primary mb-2">
              {Math.round(temperature)}°
            </div>
            <div className="text-xl text-foreground font-medium mb-1">
              {condition}
            </div>
            <div className="text-muted-foreground capitalize">
              {description}
            </div>
          </div>
          
          <div className="text-8xl opacity-80">
            {getWeatherEmoji(icon)}
          </div>
        </div>

        <div className="flex items-center gap-2 text-muted-foreground">
          <Thermometer className="h-4 w-4" />
          <span>Feels like {Math.round(feelsLike)}°</span>
        </div>
      </div>
    </Card>
  );
}

function getWeatherEmoji(icon: string): string {
  const iconMap: { [key: string]: string } = {
    '01d': '☀️', '01n': '🌙',
    '02d': '⛅', '02n': '☁️',
    '03d': '☁️', '03n': '☁️',
    '04d': '☁️', '04n': '☁️',
    '09d': '🌧️', '09n': '🌧️',
    '10d': '🌦️', '10n': '🌧️',
    '11d': '⛈️', '11n': '⛈️',
    '13d': '🌨️', '13n': '🌨️',
    '50d': '🌫️', '50n': '🌫️',
  };
  return iconMap[icon] || '☀️';
}