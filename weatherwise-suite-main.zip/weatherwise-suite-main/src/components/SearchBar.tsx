import { useState } from "react";
import { Search, MapPin } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface SearchBarProps {
  onSearch: (city: string) => void;
  isLoading?: boolean;
}

export function SearchBar({ onSearch, isLoading }: SearchBarProps) {
  const [searchTerm, setSearchTerm] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      onSearch(searchTerm.trim());
    }
  };

  const handleCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          onSearch(`${latitude},${longitude}`);
        },
        (error) => {
          console.error("Error getting location:", error);
        }
      );
    }
  };

  return (
    <div className="w-full max-w-md mx-auto mb-8">
      <form onSubmit={handleSubmit} className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search for a city..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-white/80 backdrop-blur-sm border-border/50 focus:border-primary/50 shadow-card"
            disabled={isLoading}
          />
        </div>
        
        <Button 
          type="submit" 
          disabled={isLoading || !searchTerm.trim()}
          className="shadow-card hover:shadow-floating transition-shadow"
        >
          <Search className="h-4 w-4" />
        </Button>
        
        <Button
          type="button"
          variant="outline"
          onClick={handleCurrentLocation}
          disabled={isLoading}
          className="shadow-card hover:shadow-floating transition-shadow bg-white/80 backdrop-blur-sm border-border/50"
        >
          <MapPin className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}